"""
Esquema de dados comum para todos os frameworks (MediaPipe, OpenFace, InsightFace).

Cada runner grava, por vídeo processado, um CSV "por frame" e contribui uma
linha de resumo para um CSV global de sumário. O módulo de análise
(src/analysis/aggregate.py) consome esses arquivos para gerar as métricas
comparativas e os gráficos.
"""
from __future__ import annotations

import csv
import json
import os
from dataclasses import dataclass, asdict, field
from typing import Optional


FRAME_CSV_FIELDS = [
    "framework",
    "dataset",
    "video_id",
    "frame_idx",
    "timestamp_s",
    "inference_ms",
    "detected",
    "n_landmarks",
    "confidence",
]

SUMMARY_CSV_FIELDS = [
    "framework",
    "dataset",
    "video_id",
    "granularity",       # "frame" (mediapipe/insightface) ou "video" (openface)
    "n_frames",
    "n_frames_detected",
    "detection_rate_pct",
    "duration_s",
    "mean_fps",
    "p50_latency_ms",
    "p90_latency_ms",
    "p95_latency_ms",
    "max_latency_ms",
    "avg_cpu_pct",
    "peak_rss_mb",
    "avg_gpu_util_pct",
    "peak_gpu_mem_mb",
    "gpu_available",
    "model_load_s",
]


@dataclass
class FrameResult:
    framework: str
    dataset: str
    video_id: str
    frame_idx: int
    timestamp_s: float
    inference_ms: float
    detected: bool
    n_landmarks: int
    confidence: Optional[float] = None

    def as_row(self) -> dict:
        d = asdict(self)
        d["detected"] = int(self.detected)
        return d


@dataclass
class VideoSummary:
    framework: str
    dataset: str
    video_id: str
    granularity: str
    n_frames: int
    n_frames_detected: int
    duration_s: float
    mean_fps: float
    p50_latency_ms: float
    p90_latency_ms: float
    p95_latency_ms: float
    max_latency_ms: float
    avg_cpu_pct: Optional[float]
    peak_rss_mb: Optional[float]
    avg_gpu_util_pct: Optional[float]
    peak_gpu_mem_mb: Optional[float]
    gpu_available: bool
    model_load_s: float = 0.0

    @property
    def detection_rate_pct(self) -> float:
        if self.n_frames == 0:
            return 0.0
        return 100.0 * self.n_frames_detected / self.n_frames

    def as_row(self) -> dict:
        d = asdict(self)
        d["detection_rate_pct"] = round(self.detection_rate_pct, 3)
        # reorder to match SUMMARY_CSV_FIELDS
        return {k: d.get(k) for k in SUMMARY_CSV_FIELDS}


class FrameCSVWriter:
    """Escreve resultados por frame incrementalmente em um CSV."""

    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self._file = open(path, "w", newline="", encoding="utf-8")
        self._writer = csv.DictWriter(self._file, fieldnames=FRAME_CSV_FIELDS)
        self._writer.writeheader()

    def write(self, row: FrameResult):
        self._writer.writerow(row.as_row())

    def close(self):
        self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def append_summary(summary_path: str, summary: VideoSummary):
    """Acrescenta uma linha ao CSV global de sumário (cria com cabeçalho se não existir)."""
    os.makedirs(os.path.dirname(summary_path), exist_ok=True)
    file_exists = os.path.isfile(summary_path)
    with open(summary_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=SUMMARY_CSV_FIELDS)
        if not file_exists:
            writer.writeheader()
        writer.writerow(summary.as_row())


def write_run_metadata(output_dir: str, framework: str, extra: Optional[dict] = None):
    """Grava metadados do ambiente de execução (útil para reprodutibilidade)."""
    meta = {"framework": framework}
    if extra:
        meta.update(extra)
    path = os.path.join(output_dir, framework, "run_metadata.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
