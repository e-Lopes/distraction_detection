"""
Agrega o /results/aggregate_summary.csv (uma linha por vídeo processado) em
estatísticas por (framework, dataset), prontas para tabelas e para os
gráficos de src/analysis/plots.py.

Uso:
    python -m src.analysis.aggregate --results-dir /results
"""
from __future__ import annotations

import argparse
import os

import pandas as pd


NUMERIC_COLS = [
    "n_frames",
    "n_frames_detected",
    "detection_rate_pct",
    "duration_s",
    "mean_fps",
    "p50_latency_ms",
    "p90_latency_ms",
    "p95_latency_ms",
    "max_latency_ms",
    "avg_cpu_pct",
    "peak_rss_mb",
    "avg_gpu_util_pct",
    "peak_gpu_mem_mb",
]


def load_summary(results_dir: str) -> pd.DataFrame:
    path = os.path.join(results_dir, "aggregate_summary.csv")
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"{path} não encontrado. Rode antes os containers mediapipe/insightface/openface."
        )
    df = pd.read_csv(path)
    for col in NUMERIC_COLS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def build_grouped_stats(df: pd.DataFrame) -> pd.DataFrame:
    """Uma linha por (framework, dataset) com média/desvio-padrão das métricas-chave."""
    agg_map = {
        "mean_fps": ["mean", "std"],
        "p50_latency_ms": ["mean"],
        "p95_latency_ms": ["mean"],
        "detection_rate_pct": ["mean", "std"],
        "avg_cpu_pct": ["mean"],
        "peak_rss_mb": ["mean", "max"],
        "avg_gpu_util_pct": ["mean"],
        "peak_gpu_mem_mb": ["mean", "max"],
        "n_frames": ["sum"],
        "video_id": ["count"],
    }
    grouped = df.groupby(["framework", "dataset"]).agg(agg_map)
    grouped.columns = ["_".join(c).strip("_") for c in grouped.columns]
    grouped = grouped.rename(columns={"video_id_count": "n_videos"})
    return grouped.reset_index()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", default="/results")
    args = parser.parse_args()

    df = load_summary(args.results_dir)
    print(f"[aggregate] {len(df)} vídeos no sumário bruto.")
    print(df["framework"].value_counts())

    grouped = build_grouped_stats(df)
    out_path = os.path.join(args.results_dir, "grouped_stats.csv")
    grouped.to_csv(out_path, index=False)
    print(f"[aggregate] Estatísticas agrupadas salvas em {out_path}\n")
    print(grouped.to_string(index=False))


if __name__ == "__main__":
    main()
