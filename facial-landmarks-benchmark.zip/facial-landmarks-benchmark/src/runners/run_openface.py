"""
Benchmark de extração de landmarks faciais com OpenFace 2.2.0 (CE-CLM, 68 pts).

IMPORTANTE - diferença de granularidade: o binário FeatureExtraction do
OpenFace processa o vídeo inteiro internamente (C++), não expõe callback por
frame. Por isso medimos aqui em granularidade "video": tempo total de parede
(wall-clock) do subprocesso, do qual derivamos um FPS médio e uma latência
média aproximada (tempo_total / nº_frames). CPU/RAM são amostrados no
processo filho durante a execução. Isso é comparável em FPS/detecção com
MediaPipe e InsightFace, mas não fornece distribuição de latência por frame
(p50/p95 ficam iguais à média nesse caso) — isso fica documentado na coluna
"granularity" do sumário e deve ser mencionado nas conclusões do estudo.

Uso:
    python -m src.runners.run_openface \
        --input /data/nthu_ddd --dataset nthu_ddd --output-dir /results \
        [--binary /openface/build/bin/FeatureExtraction] [--max-frames 900]
"""
from __future__ import annotations

import argparse
import csv
import os
import shutil
import subprocess
import sys
import tempfile
import time

import cv2

sys.path.insert(0, "/app")
from src.common.metrics import discover_videos
from src.common.resource_monitor import ResourceMonitor, gpu_is_available
from src.common.schema import FrameCSVWriter, FrameResult, VideoSummary, append_summary, write_run_metadata

FRAMEWORK = "openface"
DEFAULT_BINARY = "/openface/build/bin/FeatureExtraction"


def count_frames(video_path: str, max_frames: int) -> int:
    cap = cv2.VideoCapture(video_path)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    cap.release()
    if max_frames:
        return min(total, max_frames) if total else max_frames
    return total


def trim_video_if_needed(video_path: str, max_frames: int, tmp_dir: str) -> str:
    """Se --max-frames for usado, recorta o vídeo para acelerar o teste
    (OpenFace não tem flag nativa de limite de frames)."""
    if not max_frames:
        return video_path
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    out_path = os.path.join(tmp_dir, "trimmed.avi")
    fourcc = cv2.VideoWriter_fourcc(*"MJPG")
    writer = cv2.VideoWriter(out_path, fourcc, fps, (w, h))
    n = 0
    while n < max_frames:
        ok, frame = cap.read()
        if not ok:
            break
        writer.write(frame)
        n += 1
    cap.release()
    writer.release()
    return out_path


def process_video(binary: str, video_id: str, video_path: str, dataset: str, output_dir: str, max_frames: int, monitor_interval: float):
    if not os.path.isfile(binary):
        print(f"[openface] ERRO: binário não encontrado em {binary}. Verifique o build da imagem docker/openface.")
        return None

    with tempfile.TemporaryDirectory() as tmp_dir:
        input_for_run = trim_video_if_needed(video_path, max_frames, tmp_dir)
        n_frames_expected = count_frames(input_for_run, 0)

        of_out_dir = os.path.join(tmp_dir, "of_out")
        os.makedirs(of_out_dir, exist_ok=True)

        cmd = [binary, "-f", input_for_run, "-out_dir", of_out_dir, "-2Dfp", "-q"]

        t_start = time.perf_counter()
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        monitor = ResourceMonitor(interval_s=monitor_interval, pid=proc.pid)
        monitor.start()
        proc.wait()
        res_summary = monitor.stop()
        duration_s = time.perf_counter() - t_start

        if proc.returncode != 0:
            print(f"[openface] AVISO: FeatureExtraction retornou código {proc.returncode} para {video_id}")

        # localizar o CSV de saída (mesmo nome-base do vídeo de entrada)
        base = os.path.splitext(os.path.basename(input_for_run))[0]
        of_csv = os.path.join(of_out_dir, f"{base}.csv")

        n_frames = 0
        n_detected = 0
        frame_csv_path = os.path.join(output_dir, FRAMEWORK, dataset, f"{video_id}__frames.csv")
        writer = FrameCSVWriter(frame_csv_path)

        approx_latency_ms = (duration_s * 1000.0 / n_frames_expected) if n_frames_expected else 0.0

        if os.path.isfile(of_csv):
            with open(of_csv, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                reader.fieldnames = [name.strip() for name in reader.fieldnames]
                for row in reader:
                    row = {k.strip(): v.strip() for k, v in row.items()}
                    success = row.get("success", "0") == "1"
                    confidence = float(row.get("confidence", 0.0) or 0.0)
                    frame_idx = int(float(row.get("frame", n_frames))) - 1
                    timestamp_s = float(row.get("timestamp", n_frames / 30.0))

                    writer.write(
                        FrameResult(
                            framework=FRAMEWORK,
                            dataset=dataset,
                            video_id=video_id,
                            frame_idx=frame_idx,
                            timestamp_s=timestamp_s,
                            inference_ms=round(approx_latency_ms, 4),
                            detected=success,
                            n_landmarks=68 if success else 0,
                            confidence=confidence,
                        )
                    )
                    n_frames += 1
                    if success:
                        n_detected += 1
        else:
            print(f"[openface] AVISO: CSV de saída não encontrado ({of_csv}) para {video_id}; usando apenas métricas de tempo total.")
            n_frames = n_frames_expected

        writer.close()

        mean_fps = round(n_frames / duration_s, 3) if duration_s > 0 and n_frames else 0.0
        summary = VideoSummary(
            framework=FRAMEWORK,
            dataset=dataset,
            video_id=video_id,
            granularity="video",  # ver docstring do módulo
            n_frames=n_frames,
            n_frames_detected=n_detected,
            duration_s=round(duration_s, 4),
            mean_fps=mean_fps,
            p50_latency_ms=round(approx_latency_ms, 4),
            p90_latency_ms=round(approx_latency_ms, 4),
            p95_latency_ms=round(approx_latency_ms, 4),
            max_latency_ms=round(approx_latency_ms, 4),
            avg_cpu_pct=res_summary.avg_cpu_pct,
            peak_rss_mb=res_summary.peak_rss_mb,
            avg_gpu_util_pct=res_summary.avg_gpu_util_pct,
            peak_gpu_mem_mb=res_summary.peak_gpu_mem_mb,
            gpu_available=res_summary.gpu_available,
        )
        return summary


def main():
    parser = argparse.ArgumentParser(description="Benchmark OpenFace 2.2.0 (FeatureExtraction)")
    parser.add_argument("--input", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--output-dir", default="/results")
    parser.add_argument("--binary", default=DEFAULT_BINARY)
    parser.add_argument("--max-frames", type=int, default=0)
    parser.add_argument("--monitor-interval", type=float, default=0.2)
    args = parser.parse_args()

    videos = discover_videos(args.input)
    if not videos:
        print(f"[openface] Nenhum vídeo encontrado em {args.input}")
        return

    print(f"[openface] {len(videos)} vídeo(s). binário={args.binary}. NVML disponível: {gpu_is_available()}")
    write_run_metadata(args.output_dir, FRAMEWORK, {"binary": args.binary, "granularity": "video"})

    summary_path = os.path.join(args.output_dir, "aggregate_summary.csv")

    for i, (video_id, path) in enumerate(videos, 1):
        print(f"[openface] ({i}/{len(videos)}) processando {video_id} ...")
        summary = process_video(args.binary, video_id, path, args.dataset, args.output_dir, args.max_frames, args.monitor_interval)
        if summary is not None:
            append_summary(summary_path, summary)
            print(
                f"    -> {summary.n_frames} frames, {summary.mean_fps} FPS, "
                f"detecção {summary.detection_rate_pct:.1f}%, tempo_total={summary.duration_s}s"
            )

    print("[openface] concluído.")


if __name__ == "__main__":
    main()
