"""
Benchmark de extração de landmarks faciais com MediaPipe (Tasks API,
FaceLandmarker — 478 pontos incluindo íris).

Nota de API: a antiga API "Solutions" (mp.solutions.face_mesh) foi removida
das builds recentes do pacote mediapipe no PyPI; este runner usa a Tasks API
atual (mediapipe.tasks.python.vision.FaceLandmarker), que é o caminho
oficialmente suportado. Isso exige um arquivo de modelo .task (baixado no
build da imagem Docker — ver docker/mediapipe/Dockerfile).

Uso:
    python -m src.runners.run_mediapipe \
        --input /data/nthu_ddd --dataset nthu_ddd --output-dir /results \
        [--max-frames 900] [--model-path /app/models/face_landmarker.task]

Mede, por frame: latência de inferência (ms), sucesso de detecção, nº de
landmarks. Mede, por vídeo: FPS médio, percentis de latência, uso de CPU/RAM
e (se GPU disponível via NVML) utilização de GPU do sistema durante a
execução — o FaceLandmarker roda em CPU por padrão nesta build Python (não
há delegate de GPU para Python/Linux nesta versão da Tasks API).
"""
from __future__ import annotations

import argparse
import os
import sys
import time

import cv2
import mediapipe as mp
from mediapipe.tasks import python as mp_python
from mediapipe.tasks.python import vision as mp_vision

sys.path.insert(0, "/app")
from src.common.metrics import discover_videos, percentile, timer_ms
from src.common.resource_monitor import ResourceMonitor, gpu_is_available
from src.common.schema import FrameCSVWriter, FrameResult, VideoSummary, append_summary, write_run_metadata

FRAMEWORK = "mediapipe"
DEFAULT_MODEL_PATH = "/app/models/face_landmarker.task"


def process_video(landmarker, video_id: str, video_path: str, dataset: str, output_dir: str, max_frames: int, monitor_interval: float):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"[mediapipe] AVISO: não foi possível abrir {video_path}, pulando.")
        return None

    frame_csv_path = os.path.join(output_dir, FRAMEWORK, dataset, f"{video_id}__frames.csv")
    writer = FrameCSVWriter(frame_csv_path)

    monitor = ResourceMonitor(interval_s=monitor_interval)
    monitor.start()

    latencies = []
    n_detected = 0
    frame_idx = 0
    t_start = time.perf_counter()

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if max_frames and frame_idx >= max_frames:
            break

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        # timestamp precisa ser estritamente crescente; usamos o índice do
        # frame diretamente (não a escala real de tempo) para evitar colisões
        # de arredondamento em vídeos de FPS alto — suficiente para o
        # FaceLandmarker em modo VIDEO.
        with timer_ms() as t:
            result = landmarker.detect_for_video(mp_image, frame_idx)
        inference_ms = t["ms"]
        latencies.append(inference_ms)

        detected = len(result.face_landmarks) > 0
        n_landmarks = len(result.face_landmarks[0]) if detected else 0
        if detected:
            n_detected += 1

        writer.write(
            FrameResult(
                framework=FRAMEWORK,
                dataset=dataset,
                video_id=video_id,
                frame_idx=frame_idx,
                timestamp_s=frame_idx / (cap.get(cv2.CAP_PROP_FPS) or 30.0),
                inference_ms=round(inference_ms, 4),
                detected=detected,
                n_landmarks=n_landmarks,
            )
        )
        frame_idx += 1

    duration_s = time.perf_counter() - t_start
    cap.release()
    writer.close()
    res_summary = monitor.stop()

    n_frames = frame_idx
    summary = VideoSummary(
        framework=FRAMEWORK,
        dataset=dataset,
        video_id=video_id,
        granularity="frame",
        n_frames=n_frames,
        n_frames_detected=n_detected,
        duration_s=round(duration_s, 4),
        mean_fps=round(n_frames / duration_s, 3) if duration_s > 0 else 0.0,
        p50_latency_ms=round(percentile(latencies, 50), 4),
        p90_latency_ms=round(percentile(latencies, 90), 4),
        p95_latency_ms=round(percentile(latencies, 95), 4),
        max_latency_ms=round(max(latencies), 4) if latencies else 0.0,
        avg_cpu_pct=res_summary.avg_cpu_pct,
        peak_rss_mb=res_summary.peak_rss_mb,
        avg_gpu_util_pct=res_summary.avg_gpu_util_pct,
        peak_gpu_mem_mb=res_summary.peak_gpu_mem_mb,
        gpu_available=res_summary.gpu_available,
    )
    return summary


def main():
    parser = argparse.ArgumentParser(description="Benchmark MediaPipe Face Mesh")
    parser.add_argument("--input", required=True, help="Arquivo de vídeo ou diretório com vídeos")
    parser.add_argument("--dataset", required=True, help="Nome do dataset (ex: nthu_ddd, uta_rldd, custom)")
    parser.add_argument("--output-dir", default="/results")
    parser.add_argument("--max-frames", type=int, default=0, help="Limite de frames por vídeo (0 = sem limite)")
    parser.add_argument("--model-path", default=DEFAULT_MODEL_PATH, help="Caminho do arquivo .task do FaceLandmarker")
    parser.add_argument("--monitor-interval", type=float, default=0.2)
    args = parser.parse_args()

    videos = discover_videos(args.input)
    if not videos:
        print(f"[mediapipe] Nenhum vídeo encontrado em {args.input}")
        return

    if not os.path.isfile(args.model_path):
        print(f"[mediapipe] ERRO: modelo não encontrado em {args.model_path}. Verifique o build da imagem docker/mediapipe.")
        return

    print(f"[mediapipe] {len(videos)} vídeo(s) encontrados. GPU/NVML disponível: {gpu_is_available()}")

    t_load0 = time.perf_counter()
    base_options = mp_python.BaseOptions(model_asset_path=args.model_path)
    options = mp_vision.FaceLandmarkerOptions(
        base_options=base_options,
        running_mode=mp_vision.RunningMode.VIDEO,
        num_faces=1,
        min_face_detection_confidence=0.5,
        min_face_presence_confidence=0.5,
        min_tracking_confidence=0.5,
        output_face_blendshapes=False,
        output_facial_transformation_matrixes=False,
    )
    landmarker = mp_vision.FaceLandmarker.create_from_options(options)
    model_load_s = time.perf_counter() - t_load0

    write_run_metadata(
        args.output_dir,
        FRAMEWORK,
        {"model_path": args.model_path, "model_load_s": round(model_load_s, 3)},
    )

    summary_path = os.path.join(args.output_dir, "aggregate_summary.csv")

    for i, (video_id, path) in enumerate(videos, 1):
        print(f"[mediapipe] ({i}/{len(videos)}) processando {video_id} ...")
        summary = process_video(landmarker, video_id, path, args.dataset, args.output_dir, args.max_frames, args.monitor_interval)
        if summary is not None:
            summary.model_load_s = round(model_load_s, 3) if i == 1 else 0.0
            append_summary(summary_path, summary)
            print(
                f"    -> {summary.n_frames} frames, {summary.mean_fps} FPS, "
                f"detecção {summary.detection_rate_pct:.1f}%, p95={summary.p95_latency_ms}ms"
            )

    landmarker.close()
    print("[mediapipe] concluído.")


if __name__ == "__main__":
    main()
