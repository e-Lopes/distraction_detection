"""
Benchmark de extração de landmarks faciais com InsightFace (detecção RetinaFace
+ landmarks 2D-106, pacote de modelos "buffalo_l" por padrão).

Uso:
    python -m src.runners.run_insightface \
        --input /data/nthu_ddd --dataset nthu_ddd --output-dir /results \
        --gpu [--max-frames 900] [--det-size 640]

Requer GPU NVIDIA + onnxruntime-gpu para usar --gpu; caso contrário roda em CPU
(CPUExecutionProvider).
"""
from __future__ import annotations

import argparse
import os
import sys
import time

import cv2
import numpy as np
from insightface.app import FaceAnalysis

sys.path.insert(0, "/app")
from src.common.metrics import discover_videos, percentile, timer_ms
from src.common.resource_monitor import ResourceMonitor, gpu_is_available
from src.common.schema import FrameCSVWriter, FrameResult, VideoSummary, append_summary, write_run_metadata

FRAMEWORK = "insightface"


def process_video(app: FaceAnalysis, video_id: str, video_path: str, dataset: str, output_dir: str, max_frames: int, monitor_interval: float):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"[insightface] AVISO: não foi possível abrir {video_path}, pulando.")
        return None

    frame_csv_path = os.path.join(output_dir, FRAMEWORK, dataset, f"{video_id}__frames.csv")
    writer = FrameCSVWriter(frame_csv_path)

    monitor = ResourceMonitor(interval_s=monitor_interval)
    monitor.start()

    latencies = []
    n_detected = 0
    frame_idx = 0
    t_start = time.perf_counter()

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if max_frames and frame_idx >= max_frames:
            break

        with timer_ms() as t:
            faces = app.get(frame)
        inference_ms = t["ms"]
        latencies.append(inference_ms)

        detected = len(faces) > 0
        n_landmarks = 0
        confidence = None
        if detected:
            # escolhe a face de maior score/área caso haja mais de uma
            face = max(faces, key=lambda f: getattr(f, "det_score", 0.0))
            confidence = float(getattr(face, "det_score", 0.0))
            if getattr(face, "landmark_2d_106", None) is not None:
                n_landmarks = int(face.landmark_2d_106.shape[0])
            elif getattr(face, "kps", None) is not None:
                n_landmarks = int(face.kps.shape[0])
            n_detected += 1

        writer.write(
            FrameResult(
                framework=FRAMEWORK,
                dataset=dataset,
                video_id=video_id,
                frame_idx=frame_idx,
                timestamp_s=frame_idx / (cap.get(cv2.CAP_PROP_FPS) or 30.0),
                inference_ms=round(inference_ms, 4),
                detected=detected,
                n_landmarks=n_landmarks,
                confidence=confidence,
            )
        )
        frame_idx += 1

    duration_s = time.perf_counter() - t_start
    cap.release()
    writer.close()
    res_summary = monitor.stop()

    n_frames = frame_idx
    summary = VideoSummary(
        framework=FRAMEWORK,
        dataset=dataset,
        video_id=video_id,
        granularity="frame",
        n_frames=n_frames,
        n_frames_detected=n_detected,
        duration_s=round(duration_s, 4),
        mean_fps=round(n_frames / duration_s, 3) if duration_s > 0 else 0.0,
        p50_latency_ms=round(percentile(latencies, 50), 4),
        p90_latency_ms=round(percentile(latencies, 90), 4),
        p95_latency_ms=round(percentile(latencies, 95), 4),
        max_latency_ms=round(max(latencies), 4) if latencies else 0.0,
        avg_cpu_pct=res_summary.avg_cpu_pct,
        peak_rss_mb=res_summary.peak_rss_mb,
        avg_gpu_util_pct=res_summary.avg_gpu_util_pct,
        peak_gpu_mem_mb=res_summary.peak_gpu_mem_mb,
        gpu_available=res_summary.gpu_available,
    )
    return summary


def main():
    parser = argparse.ArgumentParser(description="Benchmark InsightFace")
    parser.add_argument("--input", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--output-dir", default="/results")
    parser.add_argument("--max-frames", type=int, default=0)
    parser.add_argument("--model-pack", default="buffalo_l", help="buffalo_l (preciso) ou buffalo_sc (leve/rápido)")
    parser.add_argument("--det-size", type=int, default=640)
    parser.add_argument("--gpu", action="store_true", help="Usa CUDAExecutionProvider (requer onnxruntime-gpu)")
    parser.add_argument("--monitor-interval", type=float, default=0.2)
    args = parser.parse_args()

    videos = discover_videos(args.input)
    if not videos:
        print(f"[insightface] Nenhum vídeo encontrado em {args.input}")
        return

    providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] if args.gpu else ["CPUExecutionProvider"]
    ctx_id = 0 if args.gpu else -1

    print(f"[insightface] {len(videos)} vídeo(s). providers={providers}. NVML disponível: {gpu_is_available()}")

    t_load0 = time.perf_counter()
    app = FaceAnalysis(name=args.model_pack, providers=providers)
    app.prepare(ctx_id=ctx_id, det_size=(args.det_size, args.det_size))
    model_load_s = time.perf_counter() - t_load0

    write_run_metadata(
        args.output_dir,
        FRAMEWORK,
        {
            "model_pack": args.model_pack,
            "det_size": args.det_size,
            "providers": providers,
            "model_load_s": round(model_load_s, 3),
        },
    )

    summary_path = os.path.join(args.output_dir, "aggregate_summary.csv")

    for i, (video_id, path) in enumerate(videos, 1):
        print(f"[insightface] ({i}/{len(videos)}) processando {video_id} ...")
        summary = process_video(app, video_id, path, args.dataset, args.output_dir, args.max_frames, args.monitor_interval)
        if summary is not None:
            summary.model_load_s = round(model_load_s, 3) if i == 1 else 0.0
            append_summary(summary_path, summary)
            print(
                f"    -> {summary.n_frames} frames, {summary.mean_fps} FPS, "
                f"detecção {summary.detection_rate_pct:.1f}%, p95={summary.p95_latency_ms}ms"
            )

    print("[insightface] concluído.")


if __name__ == "__main__":
    main()
